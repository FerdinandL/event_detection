========================================================================
	PROGRAM NOTES
========================================================================

	CrimeStat is a spatial statistics program that works in a Windows
environment. The current version is 4.02. The program is designed to read 
'dbf', 'shp', and ASCII files and to write selected graphical objects to 
ArcGIS, MapInfo, Surfer for Windows, ArcView Spatial Analyst, and programs 
that accept ASCII format. It will also work with Maptitude, Vertical Mapper, 
and other GIS packages. 

	The documentation for the program is found in the CrimeStat manual,
chapters 1-32.  There is also a help menu within the program (see below).

	Fixes: 
	1.	This version fixes a problem in the Getis-Ord "G" routine
		and makes the code consistent with an erratum published
		by Getis and Ord in 1993.  See Chapter 5 for the reference.

	Version 4.01 updated fixes problems identified in version 4.0:

	1.	Shape ('shp') files can now be read as the Primary File or 
		the Secondary File. Version 4.0 could only read 'dbf' files.

	2.	The Correlated Walk Analysis Prediction routine (CWA-P) 
		now produces accurate estimates when spherical (lon/lat) 
		data are used. Version 4.0 produced incorrect estimates 
		for the predicted Y-coordinate with spherical coordinates.

	3.	The Poisson-Gamma-CAR/SAR model with an exposure variable 
		and the use of block sampling now produces accurate results.  
		This model did not work properly in version 4.0.

	4.	The 'Save all' and 'Save range' options for saving the 
		output of the Bayesian Journey-to-crime Diagnostics routine 
		now work properly.

	Opening the program in Windows 8/8.1:

	1.	On some computers, Windows Defender in Windows 8/8.1 may 
		prevent CrimeStat from opening. A message may appear that says 
		"Windows protected your PC/Windows SmartScreen prevented an
		unrcognized app from starting. Running this app might put
		your PC at risk/More info":

		A.	If that occurs, click on "More info" (not on "Open") and 
			then click on "Run anyway".

		B.	The program will open and will continue to do so
			on that computer.

		C.	However, for running the program on another 
			computer, you may have to repeat this process.
	
	Known problems:

	1.	Windows Vista, Windows 7 and Windows 8 do not recognize the help 
		menu. If a user clicks on the help menu button in CrimeStat, there 
		will be no response.  However, Microsoft has developed a special 
		file that allows help menus to be viewed in these operating systems. 
		To view CrimeStat help in Vista, Windows 7 or Windows 8, it will 
		be necessary to obtain an operating system-specific file and 
		install it according to the instructions provided by Microsoft.  
		The URL is found at:

			http://support.microsoft.com/kb/917607 

	2.	Attempting to access the help menu may also cause an error 
		message when Windows Defender is running in Windows 7/8/8.1:

		A.	A dialogue opens with the title "Open File - Security
			Warning".  

		B.	Uncheck the box labeled "Always ask before opening
			this file" and then click on "Open".

		C.	The help menu will now be accessible and will continue
			to do so as long as the help file (crimestat.hlp) is
			not replaced.

	3.	For file input, be careful about the use of tabs as delimiters in 
		ASCII files. To the user, these appear identical to space 
		delimiters.  The user should check that 'tab delimiters' is 
		checked in the ASCII input screen; checking 'space delimiters' 
		will lead to an error message.

	4.	For space-time calculations, time must be defined as an
		integer number (e.g., 3, 37199).  Date formats 
		(e.g., 11/04/01 or July 30, 2002) are not permitted.
		The program will make calculations with date formats, but
		the results will not be correct.

	5.	Many of the crime travel demand module routines have separate 
		inputs from the primary and secondary files.  For these, only
		'dbf' files can be read.

	6.	The 'Trip distribution' routine takes up a lot of memory. 
		Therefore, the number of zones will be limited. For example, 
		the 32 bit Windows operating system has a maximum addressable 
		limit of 4 GB (i.e., 4 billion bytes) of RAM. With a trip 
		distribution matrix, there are M x N cells where M is 
		the number of rows (origins) and N is the number of columns 
		(destinations). With 8 bytes (64 bits) being assigned to a number 
		in a cell (including the decimal and decimal places), the maximum 
		matrix that could be loaded into memory would be about 
		22,000 x 22,000. However, this amount would not be available 
		since a lot of RAM will be taken up by the program and operating 
		system. Nevertheless, using the calculation, the storage space 
		required to save such a matrix will limit the size of the database, 
		aside from taking a very long time to be calculated. With a 64 bit 
		operating system (e.g., Windows 7 or Windows 8), the theoretical 
		maximum for addressable memory is 192 GB. Again, with 8 bytes per 
		cell, the available RAM would allow a maximum square matrix of 
		about 154,000 x 154,000 cells, but actually much less because of
		overhead used by the operating system. 

	7.	Be careful when running routines with network distance. It can 
		take a long time to complete.  The more pairs that have to be 
		calculated, the longer it will take. Further, the more complicated 
		the network, the longer it will take.  

	8.	Problems with saving and loading parameter files (*.param):

		A.	The 'Options Save Parameters' routine will not save the 
			parameters for second-level ('child') dialogues.  For 
			example, it won't save the network names and 
			characteristics for the 'Mode split' and 'Network 
			assignment' routines nor will it save the file 
			characteristics for the 'Calibrate Journey-to-crime 
			function', the 'Calculate observed origin-destination 
			trips', nor 'Calibrate impedance function' rountes.

		B.	The 'Options Load Parameters' routine will not load a 
			parameter file in which the Primary File or Secondary 
			File is a shape file. The program will crash or else 
			produce an 'Out of Memory' error message.  That is,
			a user can save a parameters file when the Primary or
			Secondary Files are 'shp' but cannot load it. 

			a.	Note that the parameter file can properly open 
				'dbf' files as the Primary or Secondary File.  
				The program can also run routines with a shape 
				file is the Primary or Secondary File.  The 
				problem occurs only when a shape file is saved 
				in a parameter file.

			b.	We are still working to fix this problem.
				But, if a user wants to save the parameters when
				the Primary or Secondary Files are shape files,
				a suggestion is to save the selection as a 
				parameter file. Then, with an ASCII editor 
				(e.g., Notepad), open the parameter file and 
				change the 'shp' extensions to 'dbf'. This will 
				allow the data and parameters to be loaded.  The
				user can then substitute the appropriate 'shp' 
				files for the loaded 'dbf' files.
		
		C.	Be careful with parameter files.  If you move them 
			between different directories or copy them to another 
			computer, they may not work and may cause the program to 
			crash  It is generally a good idea to reconstruct a 
			parameter file from scratch if difficulties emerge. 
			Another alternative is to re-save the parameter file 
			and then close down the program.  Re-open the program 
			and load in the parameter file.

	9.	Some users have periodically experienced "irrecoverable error" messages. 
		Almost always, the "irrecoverable error" message indicates a data or 
		data definition problem.  Specifically, the following could cause 
		the error to appear:


		A.	Coordinate mismatch.  The data are in projected units, 
			but the user specifies spherical (lat/lon) units;

		B.	Trying to run a single kernel interpolation, dual kernel 
			interpolation, Nnh, or STAC hot spot run without 
			defining a reference file. The reference file is 
			essential for those routines (and several others).

		C.	Errors in defining the reference file.  For example, 
			mixing up the high and low values for the X or Y 
			coordinates.

		D.	Mismatches in distance units. For example, if the 
			data are in meters, but the user specifies 'feet' on 
			the Primary File page, the program could become 
			confused when trying to convert units and produce 
			that error.

		E.	Occasionally, the error appears in Windows Vista only 
			if the user tries to run multiple simulations simultaneously.
			The solution is to run one simulation at a time.
			This will not happen in Windows XP, Windows 7 or Windows 8.






